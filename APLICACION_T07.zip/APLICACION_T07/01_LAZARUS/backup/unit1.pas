unit Unit1;

{$mode objfpc}{$H+}

interface

uses
  Classes, SysUtils, Forms, Controls, Graphics, Dialogs, ExtCtrls, StdCtrls,
  Grids;

type

  { TForm1 }

  TForm1 = class(TForm)
    BtnAdicionar: TButton;
    BtnActualizar: TButton;
    BtnAnterior: TButton;
    BtnSiguiente: TButton;
    BtnBuscar: TButton;
    BtnEliminar: TButton;
    BtnListar: TButton;
    BtnLimpiar: TButton;
    CmbSexo: TComboBox;
    EdCarnet: TEdit;
    EdNombres: TEdit;
    EdApellidos: TEdit;
    LblTitulo: TLabel;
    LblPosicion: TLabel;
    LblCarnet: TLabel;
    LblNombres: TLabel;
    LblApellidos: TLabel;
    LblSexo: TLabel;
    PnlPrincipal: TPanel;
    PnlTitulo: TPanel;
    PnlDatos: TPanel;
    PnlOperaciones: TPanel;
    SG_Personas: TStringGrid;
  private

  public

  end;

var
  Form1: TForm1;

implementation

{$R *.lfm}

end.

