
unit uTipo;

{$mode objfpc}{$H+}

interface

uses
  Classes, SysUtils;

type
  TPersona = record
    Carnet: Integer;
    Nombres: string[40];
    Apellidos: string[40];
    Sexo: Char;
  end;

  TArchivoPersona = file of TPersona;

  Tipo = class
  private
    NombreArchivo: string;
  public
    constructor Create;

    procedure Listar(Lista: TStrings);

    function BuscarCI(CI: Integer; var Persona: TPersona): Boolean;
    function BuscarNombre(Nombre: string; var Persona: TPersona): Boolean;

    function Adicionar(Persona: TPersona): Boolean;
    function Actualizar(CI: Integer; PersonaNueva: TPersona): Boolean;
    function Eliminar(CI: Integer): Boolean;
  end;

implementation

{ ----------------------------------------------- }
{ CONSTRUCTOR: CREAR ARCHIVO CON DATOS INICIALES  }
{ ----------------------------------------------- }

constructor Tipo.Create;
var
  Archivo: TArchivoPersona;
  Persona: TPersona;
begin
  NombreArchivo := '../02_ARCHIVOS/persona.dat';

  ForceDirectories('../02_ARCHIVOS');

  if not FileExists(NombreArchivo) then
  begin
    AssignFile(Archivo, NombreArchivo);
    Rewrite(Archivo);

    Persona.Carnet := 111;
    Persona.Nombres := 'Juan';
    Persona.Apellidos := 'Perez';
    Persona.Sexo := 'H';
    Write(Archivo, Persona);

    Persona.Carnet := 222;
    Persona.Nombres := 'Maria';
    Persona.Apellidos := 'Perez';
    Persona.Sexo := 'M';
    Write(Archivo, Persona);

    Persona.Carnet := 333;
    Persona.Nombres := 'Pedro';
    Persona.Apellidos := 'Justiniano';
    Persona.Sexo := 'H';
    Write(Archivo, Persona);

    CloseFile(Archivo);
  end;
end;


{ ----------------------------------------------- }
{ LISTAR TODAS LAS PERSONAS                       }
{ ----------------------------------------------- }

procedure Tipo.Listar(Lista: TStrings);
var
  Archivo: TArchivoPersona;
  Persona: TPersona;
begin
  Lista.Clear;

  if not FileExists(NombreArchivo) then
  begin
    Lista.Add('No existe el archivo persona.dat');
    Exit;
  end;

  AssignFile(Archivo, NombreArchivo);
  Reset(Archivo);

  Lista.Add('CARNET | NOMBRES | APELLIDOS | SEXO');
  Lista.Add('--------------------------------------');

  while not EOF(Archivo) do
  begin
    Read(Archivo, Persona);

    Lista.Add(
      IntToStr(Persona.Carnet) + ' | ' +
      Persona.Nombres + ' | ' +
      Persona.Apellidos + ' | ' +
      Persona.Sexo
    );
  end;

  CloseFile(Archivo);
end;


{ ----------------------------------------------- }
{ BUSCAR POR CARNET                               }
{ ----------------------------------------------- }

function Tipo.BuscarCI(CI: Integer;
  var Persona: TPersona): Boolean;
var
  Archivo: TArchivoPersona;
  Encontrado: Boolean;
  Auxiliar: TPersona;
begin
  Result := False;

  if not FileExists(NombreArchivo) then
    Exit;

  AssignFile(Archivo, NombreArchivo);
  Reset(Archivo);

  Encontrado := False;

  while not EOF(Archivo) do
  begin
    Read(Archivo, Auxiliar);

    if Auxiliar.Carnet = CI then
    begin
      Persona := Auxiliar;
      Encontrado := True;
      Break;
    end;
  end;

  CloseFile(Archivo);

  Result := Encontrado;
end;


{ ----------------------------------------------- }
{ BUSCAR POR NOMBRE                               }
{ ----------------------------------------------- }

function Tipo.BuscarNombre(Nombre: string;
  var Persona: TPersona): Boolean;
var
  Archivo: TArchivoPersona;
  Auxiliar: TPersona;
  Encontrado: Boolean;
begin
  Result := False;

  if not FileExists(NombreArchivo) then
    Exit;

  AssignFile(Archivo, NombreArchivo);
  Reset(Archivo);

  Encontrado := False;
  Nombre := UpperCase(Trim(Nombre));

  while not EOF(Archivo) do
  begin
    Read(Archivo, Auxiliar);

    if Pos(Nombre, UpperCase(Auxiliar.Nombres)) > 0 then
    begin
      Persona := Auxiliar;
      Encontrado := True;
      Break;
    end;
  end;

  CloseFile(Archivo);

  Result := Encontrado;
end;


{ ----------------------------------------------- }
{ ADICIONAR UNA PERSONA                           }
{ ----------------------------------------------- }

function Tipo.Adicionar(Persona: TPersona): Boolean;
var
  Archivo: TArchivoPersona;
  Auxiliar: TPersona;
begin
  Result := False;

  if FileExists(NombreArchivo) then
  begin
    AssignFile(Archivo, NombreArchivo);
    Reset(Archivo);

    while not EOF(Archivo) do
    begin
      Read(Archivo, Auxiliar);

      if Auxiliar.Carnet = Persona.Carnet then
      begin
        CloseFile(Archivo);
        Exit;
      end;
    end;

    CloseFile(Archivo);
  end;

  AssignFile(Archivo, NombreArchivo);
  Reset(Archivo);

  Seek(Archivo, FileSize(Archivo));
  Write(Archivo, Persona);

  CloseFile(Archivo);

  Result := True;
end;


{ ----------------------------------------------- }
{ ACTUALIZAR UNA PERSONA                          }
{ ----------------------------------------------- }

function Tipo.Actualizar(CI: Integer;
  PersonaNueva: TPersona): Boolean;
var
  Archivo: TArchivoPersona;
  Persona: TPersona;
  Posicion: Integer;
  Encontrado: Boolean;
begin
  Result := False;

  if not FileExists(NombreArchivo) then
    Exit;

  AssignFile(Archivo, NombreArchivo);
  Reset(Archivo);

  Encontrado := False;

  while not EOF(Archivo) do
  begin
    Posicion := FilePos(Archivo);
    Read(Archivo, Persona);

    if Persona.Carnet = CI then
    begin
      PersonaNueva.Carnet := CI;

      Seek(Archivo, Posicion);
      Write(Archivo, PersonaNueva);

      Encontrado := True;
      Break;
    end;
  end;

  CloseFile(Archivo);

  Result := Encontrado;
end;


{ ----------------------------------------------- }
{ ELIMINAR UNA PERSONA                            }
{ ----------------------------------------------- }

function Tipo.Eliminar(CI: Integer): Boolean;
var
  Archivo, Temporal: TArchivoPersona;
  Persona: TPersona;
  Encontrado: Boolean;
  NombreTemporal: string;
begin
  Result := False;

  if not FileExists(NombreArchivo) then
    Exit;

  NombreTemporal := '../02_ARCHIVOS/persona_temp.dat';
  Encontrado := False;

  AssignFile(Archivo, NombreArchivo);
  Reset(Archivo);

  AssignFile(Temporal, NombreTemporal);
  Rewrite(Temporal);

  while not EOF(Archivo) do
  begin
    Read(Archivo, Persona);

    if Persona.Carnet = CI then
      Encontrado := True
    else
      Write(Temporal, Persona);
  end;

  CloseFile(Archivo);
  CloseFile(Temporal);

  if Encontrado then
  begin
    DeleteFile(NombreArchivo);
    RenameFile(NombreTemporal, NombreArchivo);
    Result := True;
  end
  else
    DeleteFile(NombreTemporal);
end;

end.

