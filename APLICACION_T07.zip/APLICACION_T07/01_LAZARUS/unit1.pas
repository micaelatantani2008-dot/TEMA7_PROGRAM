
unit Unit1;

{$mode objfpc}{$H+}

interface

uses
  Classes, SysUtils, Forms, Controls, Graphics, Dialogs, ExtCtrls, StdCtrls,
  Grids, uTipo;

type

  { TForm1 }

  TForm1 = class(TForm)
    BtnAdicionar: TButton;
    BtnActualizar: TButton;
    BtnAnterior: TButton;
    BtnSiguiente: TButton;
    BtnBuscar: TButton;
    BtnEliminar: TButton;
    BtnListar: TButton;
    BtnLimpiar: TButton;
    CmbSexo: TComboBox;
    EdCarnet: TEdit;
    EdNombres: TEdit;
    EdApellidos: TEdit;
    LblTitulo: TLabel;
    LblPosicion: TLabel;
    LblCarnet: TLabel;
    LblNombres: TLabel;
    LblApellidos: TLabel;
    LblSexo: TLabel;
    PnlPrincipal: TPanel;
    PnlTitulo: TPanel;
    PnlDatos: TPanel;
    PnlOperaciones: TPanel;
    SG_Personas: TStringGrid;

    procedure FormCreate(Sender: TObject);
    procedure FormDestroy(Sender: TObject);

    procedure BtnAdicionarClick(Sender: TObject);
    procedure BtnActualizarClick(Sender: TObject);
    procedure BtnBuscarClick(Sender: TObject);
    procedure BtnEliminarClick(Sender: TObject);
    procedure BtnListarClick(Sender: TObject);
    procedure BtnLimpiarClick(Sender: TObject);
    procedure BtnAnteriorClick(Sender: TObject);
    procedure BtnSiguienteClick(Sender: TObject);

  private
    FTipo: Tipo;
    FLista: TStringList;
    FIndice: Integer;

    procedure CargarListado;
    procedure MostrarRegistro(Indice: Integer);
    procedure LimpiarCampos;
    procedure SeleccionarCarnet(CI: Integer);

  public

  end;

var
  Form1: TForm1;

implementation

{$R *.lfm}

{ INICIALIZAR FORMULARIO }

procedure TForm1.FormCreate(Sender: TObject);
begin
  FTipo := Tipo.Create;
  FLista := TStringList.Create;
  FIndice := -1;

  // Conectar botones
  BtnAdicionar.OnClick := @BtnAdicionarClick;
  BtnActualizar.OnClick := @BtnActualizarClick;
  BtnBuscar.OnClick := @BtnBuscarClick;
  BtnEliminar.OnClick := @BtnEliminarClick;
  BtnListar.OnClick := @BtnListarClick;
  BtnLimpiar.OnClick := @BtnLimpiarClick;
  BtnAnterior.OnClick := @BtnAnteriorClick;
  BtnSiguiente.OnClick := @BtnSiguienteClick;

  // Configurar sexo
  CmbSexo.Items.Clear;
  CmbSexo.Items.Add('H');
  CmbSexo.Items.Add('M');

  // Configurar tabla
  SG_Personas.ColCount := 4;
  SG_Personas.RowCount := 2;
  SG_Personas.FixedRows := 1;
  SG_Personas.FixedCols := 0;

  SG_Personas.Cells[0,0] := 'CARNET';
  SG_Personas.Cells[1,0] := 'NOMBRES';
  SG_Personas.Cells[2,0] := 'APELLIDOS';
  SG_Personas.Cells[3,0] := 'SEXO';

  SG_Personas.ColWidths[0] := 130;
  SG_Personas.ColWidths[1] := 200;
  SG_Personas.ColWidths[2] := 200;
  SG_Personas.ColWidths[3] := 80;

  CargarListado;
end;

{ LIBERAR MEMORIA }

procedure TForm1.FormDestroy(Sender: TObject);
begin
  FTipo.Free;
  FLista.Free;
end;

{ CARGAR PERSONAS EN LA TABLA }

procedure TForm1.CargarListado;
var
  Partes: TStringList;
  i, Fila: Integer;
begin
  FTipo.Listar(FLista);

  SG_Personas.RowCount := 2;

  SG_Personas.Cells[0,0] := 'CARNET';
  SG_Personas.Cells[1,0] := 'NOMBRES';
  SG_Personas.Cells[2,0] := 'APELLIDOS';
  SG_Personas.Cells[3,0] := 'SEXO';

  Fila := 1;

  Partes := TStringList.Create;

  try
    // Las dos primeras líneas son encabezados
    for i := 2 to FLista.Count - 1 do
    begin
      Partes.Clear;

      ExtractStrings(['|'], [], PChar(FLista[i]), Partes);

      if Partes.Count >= 4 then
      begin
        if Fila >= SG_Personas.RowCount then
          SG_Personas.RowCount := SG_Personas.RowCount + 1;

        SG_Personas.Cells[0,Fila] := Trim(Partes[0]);
        SG_Personas.Cells[1,Fila] := Trim(Partes[1]);
        SG_Personas.Cells[2,Fila] := Trim(Partes[2]);
        SG_Personas.Cells[3,Fila] := Trim(Partes[3]);

        Fila := Fila + 1;
      end;
    end;
  finally
    Partes.Free;
  end;

  FIndice := -1;
  LblPosicion.Caption := 'Registro 0 de ' +
    IntToStr(Fila - 1);
end;

{ MOSTRAR UN REGISTRO }

procedure TForm1.MostrarRegistro(Indice: Integer);
var
  Partes: TStringList;
begin
  if (Indice < 0) or (Indice >= FLista.Count - 2) then
    Exit;

  Partes := TStringList.Create;

  try
    ExtractStrings(['|'], [], PChar(FLista[Indice + 2]), Partes);

    if Partes.Count >= 4 then
    begin
      EdCarnet.Text := Trim(Partes[0]);
      EdNombres.Text := Trim(Partes[1]);
      EdApellidos.Text := Trim(Partes[2]);

      CmbSexo.ItemIndex := CmbSexo.Items.IndexOf(Trim(Partes[3]));

      FIndice := Indice;

      LblPosicion.Caption := 'Registro ' +
        IntToStr(FIndice + 1) + ' de ' +
        IntToStr(FLista.Count - 2);
    end;
  finally
    Partes.Free;
  end;
end;

{ BUSCAR UNA PERSONA EN LA TABLA POR CARNET }

procedure TForm1.SeleccionarCarnet(CI: Integer);
var
  i: Integer;
begin
  for i := 1 to SG_Personas.RowCount - 1 do
  begin
    if StrToIntDef(SG_Personas.Cells[0,i], -1) = CI then
    begin
      SG_Personas.Row := i;
      MostrarRegistro(i - 1);
      Exit;
    end;
  end;
end;

{ LIMPIAR CAMPOS }

procedure TForm1.LimpiarCampos;
begin
  EdCarnet.Clear;
  EdNombres.Clear;
  EdApellidos.Clear;
  CmbSexo.ItemIndex := -1;

  EdCarnet.SetFocus;
end;

{ ADICIONAR PERSONA }

procedure TForm1.BtnAdicionarClick(Sender: TObject);
var
  Persona: TPersona;
begin
  if (Trim(EdCarnet.Text) = '') or
     (Trim(EdNombres.Text) = '') or
     (Trim(EdApellidos.Text) = '') or
     (CmbSexo.ItemIndex = -1) then
  begin
    ShowMessage('Complete todos los campos.');
    Exit;
  end;

  if not TryStrToInt(EdCarnet.Text, Persona.Carnet) then
  begin
    ShowMessage('El carnet debe ser numerico.');
    Exit;
  end;

  if (Length(EdNombres.Text) > 40) or
     (Length(EdApellidos.Text) > 40) then
  begin
    ShowMessage('Los nombres y apellidos permiten maximo 40 caracteres.');
    Exit;
  end;

  Persona.Nombres := Trim(EdNombres.Text);
  Persona.Apellidos := Trim(EdApellidos.Text);
  Persona.Sexo := CmbSexo.Text[1];

  if FTipo.Adicionar(Persona) then
  begin
    ShowMessage('Persona adicionada correctamente.');
    CargarListado;
    SeleccionarCarnet(Persona.Carnet);
  end
  else
    ShowMessage('No se pudo adicionar. El carnet ya existe.');
end;

{ ACTUALIZAR PERSONA }

procedure TForm1.BtnActualizarClick(Sender: TObject);
var
  CI: Integer;
  Persona: TPersona;
begin
  if not TryStrToInt(EdCarnet.Text, CI) then
  begin
    ShowMessage('Ingrese un carnet valido.');
    Exit;
  end;

  if (Trim(EdNombres.Text) = '') or
     (Trim(EdApellidos.Text) = '') or
     (CmbSexo.ItemIndex = -1) then
  begin
    ShowMessage('Complete todos los campos.');
    Exit;
  end;

  if (Length(EdNombres.Text) > 40) or
     (Length(EdApellidos.Text) > 40) then
  begin
    ShowMessage('Los nombres y apellidos permiten maximo 40 caracteres.');
    Exit;
  end;

  Persona.Carnet := CI;
  Persona.Nombres := Trim(EdNombres.Text);
  Persona.Apellidos := Trim(EdApellidos.Text);
  Persona.Sexo := CmbSexo.Text[1];

  if FTipo.Actualizar(CI, Persona) then
  begin
    ShowMessage('Persona actualizada correctamente.');
    CargarListado;
    SeleccionarCarnet(CI);
  end
  else
    ShowMessage('No se encontro el carnet.');
end;

{ BUSCAR POR CARNET O NOMBRE }

procedure TForm1.BtnBuscarClick(Sender: TObject);
var
  Persona: TPersona;
  CI: Integer;
  TextoBuscar: string;
  Encontrado: Boolean;
begin
  TextoBuscar := Trim(EdCarnet.Text);

  if TextoBuscar = '' then
    TextoBuscar := Trim(EdNombres.Text);

  if TextoBuscar = '' then
  begin
    ShowMessage('Ingrese un carnet o un nombre para buscar.');
    Exit;
  end;

  if TryStrToInt(TextoBuscar, CI) then
    Encontrado := FTipo.BuscarCI(CI, Persona)
  else
    Encontrado := FTipo.BuscarNombre(TextoBuscar, Persona);

  if Encontrado then
  begin
    EdCarnet.Text := IntToStr(Persona.Carnet);
    EdNombres.Text := Persona.Nombres;
    EdApellidos.Text := Persona.Apellidos;
    CmbSexo.ItemIndex := CmbSexo.Items.IndexOf(Persona.Sexo);

    CargarListado;
    SeleccionarCarnet(Persona.Carnet);

    ShowMessage('Persona encontrada.');
  end
  else
    ShowMessage('No se encontro la persona.');
end;

{ ELIMINAR PERSONA }

procedure TForm1.BtnEliminarClick(Sender: TObject);
var
  CI: Integer;
begin
  if not TryStrToInt(EdCarnet.Text, CI) then
  begin
    ShowMessage('Ingrese un carnet valido.');
    Exit;
  end;

  if MessageDlg('¿Esta seguro de eliminar esta persona?',
     mtConfirmation, [mbYes, mbNo], 0) = mrYes then
  begin
    if FTipo.Eliminar(CI) then
    begin
      ShowMessage('Persona eliminada correctamente.');
      LimpiarCampos;
      CargarListado;
    end
    else
      ShowMessage('No se encontro el carnet.');
  end;
end;

{ LISTAR PERSONAS }

procedure TForm1.BtnListarClick(Sender: TObject);
begin
  CargarListado;
  LimpiarCampos;
  ShowMessage('Listado actualizado.');
end;

{ LIMPIAR }

procedure TForm1.BtnLimpiarClick(Sender: TObject);
begin
  LimpiarCampos;
end;

{ REGISTRO ANTERIOR }

procedure TForm1.BtnAnteriorClick(Sender: TObject);
begin
  if FIndice > 0 then
    MostrarRegistro(FIndice - 1)
  else
    ShowMessage('No hay un registro anterior.');
end;

{ REGISTRO SIGUIENTE }

procedure TForm1.BtnSiguienteClick(Sender: TObject);
begin
  if FIndice < FLista.Count - 3 then
    MostrarRegistro(FIndice + 1)
  else
    ShowMessage('No hay un registro siguiente.');
end;

end.

